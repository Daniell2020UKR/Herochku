# ⚠️ !STOP! ⚠️

Do NOT place any new files here!
Read [the docs](https://friendly-telegram.gitlab.io/modules/core#loading-and-unloading-modules "the docs") to learn how to add new modules
