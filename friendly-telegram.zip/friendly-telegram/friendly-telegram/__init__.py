# pylint: skip-file # This file is empty, no need to lint it
# Otherwise we get warnings about invalid-name because the module is called friendly-telegram not friendly_telegram
# Placeholder to make this a module, so we can do relative imports
