Try to keep in mind the immortal words of Bill and Ted:
> Be excellent to each other.

Above all, do not be fooled by the "contributor covenant". Here, we use code meritocracy. Good code = merge, bad code = reject, race, gender does not matter.
